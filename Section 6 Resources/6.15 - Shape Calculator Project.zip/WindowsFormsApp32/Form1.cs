﻿using System;
using System.Windows.Forms;

namespace WindowsFormsApp32
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pnlRectLabels_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(pnlRectLabels, "Click to copy to clipboard.");
        }

        private void pnlRectLabels_DoubleClick(object sender, EventArgs e)
        {
            try
            {
                Clipboard.SetText(lblArea.Text + "\n" + lblPeri.Text);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
           
        }

        private void btnAreaPerimeter_Click(object sender, EventArgs e)
        {                                //8->"8"->8 , and 8>0
                                         //-8 ->"-8"->-8 -8>0 fail
            var hBox = double.TryParse(txtHori.Text, out double H) && H > 0;
            var vBox = double.TryParse(txtVert.Text, out double V) && V > 0;
            if (hBox && vBox)
            {
                int round = (int)nmrRect.Value;
                lblArea.Text = $"Area:{Math.Round(H * V, round)}";
                lblPeri.Text = $"Perimeter:{Math.Round(2 * H + 2 * V, round)}";
            }
            else
                MessageBox.Show("Input not numeric or 0 or less than 0.");
        }

        private void btnNotes_Click(object sender, EventArgs e)
        {
            Notes nt = new Notes();
            nt.Show();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch(comboBox1.SelectedIndex)
            {
                case 0:
                    pnlCyl.Visible = false;
                    pnlRect.Visible = true;
                    break;
                case 1:
                    pnlCyl.Visible = true;
                    break;


            }
        }

        private void btnVolume_Click(object sender, EventArgs e)
        {
            var radius = double.TryParse(txtRadiusCyl.Text, out double r) && r >= 0;
            var height = double.TryParse(txtHeightCyl.Text, out double h) && h >= 0;
            if (radius && height)
            {
                int round = (int)nmrCylVolume.Value;
                lblVolume.Text = $"Volume:{Math.Round(Math.PI * r * r * h, round)}";
            }
            else
                MessageBox.Show("Either radius or height not in the right format.");
        }

        private void pnlVolumeLabel_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            try
            {
                Clipboard.SetText(lblVolume.Text);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            
        }
    }
}
