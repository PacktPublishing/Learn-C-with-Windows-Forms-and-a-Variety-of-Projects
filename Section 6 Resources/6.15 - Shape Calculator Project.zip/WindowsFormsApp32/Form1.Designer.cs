﻿namespace WindowsFormsApp32
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.pnlRect = new System.Windows.Forms.Panel();
            this.txtHori = new System.Windows.Forms.TextBox();
            this.pnlRectLabels = new System.Windows.Forms.Panel();
            this.lblPeri = new System.Windows.Forms.Label();
            this.lblArea = new System.Windows.Forms.Label();
            this.nmrRect = new System.Windows.Forms.NumericUpDown();
            this.btnAreaPerimeter = new System.Windows.Forms.Button();
            this.txtVert = new System.Windows.Forms.TextBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.btnNotes = new System.Windows.Forms.Button();
            this.pnlCyl = new System.Windows.Forms.Panel();
            this.txtRadiusCyl = new System.Windows.Forms.TextBox();
            this.pnlVolumeLabel = new System.Windows.Forms.Panel();
            this.lblVolume = new System.Windows.Forms.Label();
            this.nmrCylVolume = new System.Windows.Forms.NumericUpDown();
            this.btnVolume = new System.Windows.Forms.Button();
            this.txtHeightCyl = new System.Windows.Forms.TextBox();
            this.picCyl = new System.Windows.Forms.PictureBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.pnlRect.SuspendLayout();
            this.pnlRectLabels.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmrRect)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.pnlCyl.SuspendLayout();
            this.pnlVolumeLabel.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmrCylVolume)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCyl)).BeginInit();
            this.SuspendLayout();
            // 
            // pnlRect
            // 
            this.pnlRect.Controls.Add(this.txtHori);
            this.pnlRect.Controls.Add(this.pnlRectLabels);
            this.pnlRect.Controls.Add(this.nmrRect);
            this.pnlRect.Controls.Add(this.btnAreaPerimeter);
            this.pnlRect.Controls.Add(this.txtVert);
            this.pnlRect.Controls.Add(this.pictureBox1);
            this.pnlRect.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.pnlRect.Location = new System.Drawing.Point(12, 144);
            this.pnlRect.Name = "pnlRect";
            this.pnlRect.Size = new System.Drawing.Size(988, 614);
            this.pnlRect.TabIndex = 0;
            // 
            // txtHori
            // 
            this.txtHori.Location = new System.Drawing.Point(211, 374);
            this.txtHori.Name = "txtHori";
            this.txtHori.Size = new System.Drawing.Size(100, 32);
            this.txtHori.TabIndex = 5;
            // 
            // pnlRectLabels
            // 
            this.pnlRectLabels.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlRectLabels.Controls.Add(this.lblPeri);
            this.pnlRectLabels.Controls.Add(this.lblArea);
            this.pnlRectLabels.Location = new System.Drawing.Point(575, 118);
            this.pnlRectLabels.Name = "pnlRectLabels";
            this.pnlRectLabels.Size = new System.Drawing.Size(410, 182);
            this.pnlRectLabels.TabIndex = 4;
            this.pnlRectLabels.DoubleClick += new System.EventHandler(this.pnlRectLabels_DoubleClick);
            this.pnlRectLabels.MouseHover += new System.EventHandler(this.pnlRectLabels_MouseHover);
            // 
            // lblPeri
            // 
            this.lblPeri.AutoSize = true;
            this.lblPeri.Location = new System.Drawing.Point(20, 56);
            this.lblPeri.Name = "lblPeri";
            this.lblPeri.Size = new System.Drawing.Size(0, 26);
            this.lblPeri.TabIndex = 1;
            // 
            // lblArea
            // 
            this.lblArea.AutoSize = true;
            this.lblArea.Location = new System.Drawing.Point(17, 17);
            this.lblArea.Name = "lblArea";
            this.lblArea.Size = new System.Drawing.Size(0, 26);
            this.lblArea.TabIndex = 0;
            // 
            // nmrRect
            // 
            this.nmrRect.Location = new System.Drawing.Point(575, 57);
            this.nmrRect.Name = "nmrRect";
            this.nmrRect.Size = new System.Drawing.Size(120, 32);
            this.nmrRect.TabIndex = 3;
            this.nmrRect.ValueChanged += new System.EventHandler(this.btnAreaPerimeter_Click);
            // 
            // btnAreaPerimeter
            // 
            this.btnAreaPerimeter.Location = new System.Drawing.Point(575, 14);
            this.btnAreaPerimeter.Name = "btnAreaPerimeter";
            this.btnAreaPerimeter.Size = new System.Drawing.Size(182, 37);
            this.btnAreaPerimeter.TabIndex = 2;
            this.btnAreaPerimeter.Text = "Area/Perimeter";
            this.btnAreaPerimeter.UseVisualStyleBackColor = true;
            this.btnAreaPerimeter.Click += new System.EventHandler(this.btnAreaPerimeter_Click);
            // 
            // txtVert
            // 
            this.txtVert.Location = new System.Drawing.Point(446, 174);
            this.txtVert.Name = "txtVert";
            this.txtVert.Size = new System.Drawing.Size(100, 32);
            this.txtVert.TabIndex = 1;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::WindowsFormsApp32.Properties.Resources.rectangle_with_braces1;
            this.pictureBox1.Location = new System.Drawing.Point(12, 14);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(514, 380);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // btnNotes
            // 
            this.btnNotes.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.btnNotes.Location = new System.Drawing.Point(24, 64);
            this.btnNotes.Name = "btnNotes";
            this.btnNotes.Size = new System.Drawing.Size(78, 38);
            this.btnNotes.TabIndex = 1;
            this.btnNotes.Text = "Notes";
            this.btnNotes.UseVisualStyleBackColor = true;
            this.btnNotes.Click += new System.EventHandler(this.btnNotes_Click);
            // 
            // pnlCyl
            // 
            this.pnlCyl.Controls.Add(this.txtRadiusCyl);
            this.pnlCyl.Controls.Add(this.pnlVolumeLabel);
            this.pnlCyl.Controls.Add(this.nmrCylVolume);
            this.pnlCyl.Controls.Add(this.btnVolume);
            this.pnlCyl.Controls.Add(this.txtHeightCyl);
            this.pnlCyl.Controls.Add(this.picCyl);
            this.pnlCyl.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.pnlCyl.Location = new System.Drawing.Point(4, 108);
            this.pnlCyl.Name = "pnlCyl";
            this.pnlCyl.Size = new System.Drawing.Size(988, 614);
            this.pnlCyl.TabIndex = 2;
            // 
            // txtRadiusCyl
            // 
            this.txtRadiusCyl.Location = new System.Drawing.Point(321, 53);
            this.txtRadiusCyl.Name = "txtRadiusCyl";
            this.txtRadiusCyl.Size = new System.Drawing.Size(100, 32);
            this.txtRadiusCyl.TabIndex = 5;
            // 
            // pnlVolumeLabel
            // 
            this.pnlVolumeLabel.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlVolumeLabel.Controls.Add(this.lblVolume);
            this.pnlVolumeLabel.Location = new System.Drawing.Point(575, 118);
            this.pnlVolumeLabel.Name = "pnlVolumeLabel";
            this.pnlVolumeLabel.Size = new System.Drawing.Size(410, 182);
            this.pnlVolumeLabel.TabIndex = 4;
            this.pnlVolumeLabel.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.pnlVolumeLabel_MouseDoubleClick);
            // 
            // lblVolume
            // 
            this.lblVolume.AutoSize = true;
            this.lblVolume.Location = new System.Drawing.Point(20, 56);
            this.lblVolume.Name = "lblVolume";
            this.lblVolume.Size = new System.Drawing.Size(0, 26);
            this.lblVolume.TabIndex = 1;
            // 
            // nmrCylVolume
            // 
            this.nmrCylVolume.Location = new System.Drawing.Point(575, 57);
            this.nmrCylVolume.Name = "nmrCylVolume";
            this.nmrCylVolume.Size = new System.Drawing.Size(120, 32);
            this.nmrCylVolume.TabIndex = 3;
            this.nmrCylVolume.ValueChanged += new System.EventHandler(this.btnVolume_Click);
            // 
            // btnVolume
            // 
            this.btnVolume.Location = new System.Drawing.Point(575, 14);
            this.btnVolume.Name = "btnVolume";
            this.btnVolume.Size = new System.Drawing.Size(120, 37);
            this.btnVolume.TabIndex = 2;
            this.btnVolume.Text = "Volume";
            this.btnVolume.UseVisualStyleBackColor = true;
            this.btnVolume.Click += new System.EventHandler(this.btnVolume_Click);
            // 
            // txtHeightCyl
            // 
            this.txtHeightCyl.Location = new System.Drawing.Point(454, 281);
            this.txtHeightCyl.Name = "txtHeightCyl";
            this.txtHeightCyl.Size = new System.Drawing.Size(100, 32);
            this.txtHeightCyl.TabIndex = 1;
            // 
            // picCyl
            // 
            this.picCyl.Image = global::WindowsFormsApp32.Properties.Resources.cylinder;
            this.picCyl.Location = new System.Drawing.Point(12, 14);
            this.picCyl.Name = "picCyl";
            this.picCyl.Size = new System.Drawing.Size(493, 610);
            this.picCyl.SizeMode = System.Windows.Forms.PictureBoxSizeMode.CenterImage;
            this.picCyl.TabIndex = 0;
            this.picCyl.TabStop = false;
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Rectangle",
            "Cylinder"});
            this.comboBox1.Location = new System.Drawing.Point(133, 64);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 33);
            this.comboBox1.TabIndex = 3;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1013, 770);
            this.Controls.Add(this.comboBox1);
            this.Controls.Add(this.btnNotes);
            this.Controls.Add(this.pnlCyl);
            this.Controls.Add(this.pnlRect);
            this.Name = "Form1";
            this.Text = "Form1";
            this.pnlRect.ResumeLayout(false);
            this.pnlRect.PerformLayout();
            this.pnlRectLabels.ResumeLayout(false);
            this.pnlRectLabels.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmrRect)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.pnlCyl.ResumeLayout(false);
            this.pnlCyl.PerformLayout();
            this.pnlVolumeLabel.ResumeLayout(false);
            this.pnlVolumeLabel.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.nmrCylVolume)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picCyl)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlRect;
        private System.Windows.Forms.TextBox txtHori;
        private System.Windows.Forms.Panel pnlRectLabels;
        private System.Windows.Forms.Label lblPeri;
        private System.Windows.Forms.Label lblArea;
        private System.Windows.Forms.NumericUpDown nmrRect;
        private System.Windows.Forms.Button btnAreaPerimeter;
        private System.Windows.Forms.TextBox txtVert;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btnNotes;
        private System.Windows.Forms.Panel pnlCyl;
        private System.Windows.Forms.TextBox txtRadiusCyl;
        private System.Windows.Forms.Panel pnlVolumeLabel;
        private System.Windows.Forms.Label lblVolume;
        private System.Windows.Forms.NumericUpDown nmrCylVolume;
        private System.Windows.Forms.Button btnVolume;
        private System.Windows.Forms.TextBox txtHeightCyl;
        private System.Windows.Forms.PictureBox picCyl;
        private System.Windows.Forms.ComboBox comboBox1;
    }
}

