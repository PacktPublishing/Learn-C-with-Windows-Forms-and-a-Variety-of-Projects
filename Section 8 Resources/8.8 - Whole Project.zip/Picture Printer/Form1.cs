﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Picture_Printer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
           printDocument1.DefaultPageSettings.Landscape = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.Yellow;
            pictureBox2.BackColor = Color.WhiteSmoke;
            pictureBox3.BackColor = Color.WhiteSmoke;
            pictureBox4.BackColor = Color.WhiteSmoke;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.WhiteSmoke;
            pictureBox2.BackColor = Color.Yellow;
            pictureBox3.BackColor = Color.WhiteSmoke;
            pictureBox4.BackColor = Color.WhiteSmoke;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.WhiteSmoke;
            pictureBox2.BackColor = Color.WhiteSmoke;
            pictureBox3.BackColor = Color.WhiteSmoke;
            pictureBox4.BackColor = Color.Yellow;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.WhiteSmoke;
            pictureBox2.BackColor = Color.WhiteSmoke;
            pictureBox3.BackColor = Color.Yellow;
            pictureBox4.BackColor = Color.WhiteSmoke;
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            if(openFileDialog1.ShowDialog()==DialogResult.OK)
            {
                try
                {
                    if (pictureBox1.BackColor == Color.Yellow)
                        pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                    else if (pictureBox2.BackColor == Color.Yellow)
                        pictureBox2.Image = Image.FromFile(openFileDialog1.FileName);
                    else if (pictureBox3.BackColor == Color.Yellow)
                        pictureBox3.Image = Image.FromFile(openFileDialog1.FileName);
                    else if (pictureBox4.BackColor == Color.Yellow)
                        pictureBox4.Image = Image.FromFile(openFileDialog1.FileName);
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (printDialog1.ShowDialog() == DialogResult.OK)
                try
                {
                    printDocument1.Print();
                }
                catch(Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }               
        }
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            using (Bitmap imgToPrint = new Bitmap(tableLayoutPanel1.Width, tableLayoutPanel1.Height))
            {
                tableLayoutPanel1.DrawToBitmap(imgToPrint, 
                    new Rectangle(0, 0, imgToPrint.Width, imgToPrint.Height));
                e.Graphics.DrawImage(imgToPrint, 10, 10);
            }
            
        }
        private void btnPrintPreview_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }
    }
}