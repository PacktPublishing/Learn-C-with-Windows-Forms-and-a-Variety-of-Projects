﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;//Path class
using System.Net;//web client class
using System.Net.Mail;
using System.Text.RegularExpressions;
using System.Windows.Forms;


namespace Picture_Printer
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            printDocument1.DefaultPageSettings.Landscape = true;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.Yellow;
            pictureBox2.BackColor = Color.WhiteSmoke;
            pictureBox3.BackColor = Color.WhiteSmoke;
            pictureBox4.BackColor = Color.WhiteSmoke;
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.WhiteSmoke;
            pictureBox2.BackColor = Color.Yellow;
            pictureBox3.BackColor = Color.WhiteSmoke;
            pictureBox4.BackColor = Color.WhiteSmoke;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.WhiteSmoke;
            pictureBox2.BackColor = Color.WhiteSmoke;
            pictureBox3.BackColor = Color.WhiteSmoke;
            pictureBox4.BackColor = Color.Yellow;
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            pictureBox1.BackColor = Color.WhiteSmoke;
            pictureBox2.BackColor = Color.WhiteSmoke;
            pictureBox3.BackColor = Color.Yellow;
            pictureBox4.BackColor = Color.WhiteSmoke;
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                try
                {
                    if (pictureBox1.BackColor == Color.Yellow)
                        pictureBox1.Image = Image.FromFile(openFileDialog1.FileName);
                    else if (pictureBox2.BackColor == Color.Yellow)
                        pictureBox2.Image = Image.FromFile(openFileDialog1.FileName);
                    else if (pictureBox3.BackColor == Color.Yellow)
                        pictureBox3.Image = Image.FromFile(openFileDialog1.FileName);
                    else if (pictureBox4.BackColor == Color.Yellow)
                        pictureBox4.Image = Image.FromFile(openFileDialog1.FileName);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            if (printDialog1.ShowDialog() == DialogResult.OK)
                try
                {
                    printDocument1.Print();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
        }
        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            using (Bitmap imgToPrint = new Bitmap(tableLayoutPanel1.Width, tableLayoutPanel1.Height))
            {
                tableLayoutPanel1.DrawToBitmap(imgToPrint,
                    new Rectangle(0, 0, imgToPrint.Width, imgToPrint.Height));
                e.Graphics.DrawImage(imgToPrint, 10, 10);
            }

        }
        private void btnPrintPreview_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void btnDownLoad_Click(object sender, EventArgs e)
        {
            if (Uri.TryCreate(txtURI.Text, UriKind.Absolute, out Uri uri))
            {
                string ext = Path.GetExtension(txtURI.Text);
                if (ext == ".jpg" || ext == ".jpeg" || ext == ".png" || ext == ".tiff")
                {
                    if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                    {
                        using (WebClient client = new WebClient())
                        {
                            client.DownloadFile(uri, saveFileDialog1.FileName);
                        }
                    }
                }
                else
                    MessageBox.Show("Make sure it's an image file.");
            }
            else
                MessageBox.Show("Invalid Internet Address");
        }

        private void btnEmail_Click(object sender, EventArgs e)
        {
            try
            {
                if (Regex.IsMatch(txtEmail.Text, @"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*"))
                {
                    using (SmtpClient smtp = new SmtpClient())
                    using (MemoryStream stream = new MemoryStream())
                    using (Bitmap imgToEmail = new Bitmap(tableLayoutPanel1.Width, tableLayoutPanel1.Height))
                    {
                        MailMessage message = new MailMessage();
                        tableLayoutPanel1.DrawToBitmap(imgToEmail, new Rectangle(0, 0, imgToEmail.Width, imgToEmail.Height));
                        imgToEmail.Save(stream, ImageFormat.Jpeg);
                        stream.Position = 0;
                        message.Attachments.Add(new Attachment(stream, "image/jpeg"));
                        message.From = new MailAddress("enter your email here");
                        message.To.Add(new MailAddress(txtEmail.Text));
                        message.Subject = "Test Email With Image Attachment";
                        message.IsBodyHtml = false;
                        smtp.Port = 587;
                        smtp.Host = "smtp.gmail.com";
                        smtp.EnableSsl = true;
                        smtp.UseDefaultCredentials = false;
                        smtp.Credentials = new NetworkCredential("enter your email here", "enter your password here");
                        smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
                        smtp.Send(message);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
