﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Fin_Calculator
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        private void btnCalculate_Click(object sender, EventArgs e)
        {
            decimal.TryParse(txtP.Text, out decimal P);
            double.TryParse(txtT.Text, out double T);
            double.TryParse(txtR.Text, out double R);
            int.TryParse(txtN.Text, out int N);
            if (P >= 0 && T >= 0 && R >= 0 && N > 0)
            {
               var dValue=P*(decimal)Math.Pow(1 + (R / 100) / N, N * T);
                lblOutput.Text = $"Discrete value:{dValue:C}\n";
                var cValue = P * (decimal)Math.Pow(Math.E, R/100 * T);
                lblOutput.Text += $"Continous value:{cValue:C}";
            }
            else
                MessageBox.Show("Check your input.");

        }

        private void printPreviewToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            printPreviewDialog1.Document = printDocument1;
            printPreviewDialog1.ShowDialog();
        }

        private void fontToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
        }

        private void fontColorToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            colorDialog1.ShowDialog();
        }

        private void printToolStripMenuItem1_Click(object sender, EventArgs e)
        {
            try
            {
                if (printDialog1.ShowDialog() == DialogResult.OK)
                    printDocument1.Print();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void printDocument1_PrintPage(object sender, System.Drawing.Printing.PrintPageEventArgs e)
        {
            if(tabControl1.SelectedTab==tabFormulas)
            {
                int.TryParse(txtLeftMargin.Text, out int left);
                int.TryParse(txtUpperMargin.Text, out int upper);
                if (left >= 0 && upper >= 0)
                    e.Graphics.DrawImage(pictureBox1.Image, new Point(left, upper));
                else
                    e.Graphics.DrawImage(pictureBox1.Image, new Point(10, 10));
            }
            else
            {
                string txtToPrint = $"P:{txtP.Text}\nR:{txtR.Text}\n" +
                    $"T:{txtT.Text}\n" +
                    $"N:{txtN.Text}\n" +
                    lblOutput.Text;
                e.Graphics.DrawString(txtToPrint, fontDialog1.Font,
                    new SolidBrush(colorDialog1.Color), e.MarginBounds);
            }
           
        }
    }
}
