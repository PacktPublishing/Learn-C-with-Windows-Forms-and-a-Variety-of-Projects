﻿namespace Fin_Calculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabCalculate = new System.Windows.Forms.TabPage();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.lblOutput = new System.Windows.Forms.Label();
            this.txtN = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtR = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.txtT = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.txtP = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.tabFormulas = new System.Windows.Forms.TabPage();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.optionsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fontToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.fontColorToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.marginsToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.leftToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.txtLeftMargin = new System.Windows.Forms.ToolStripTextBox();
            this.upperToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.txtUpperMargin = new System.Windows.Forms.ToolStripTextBox();
            this.optionsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printPreviewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.printToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fontColorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.marginsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.leftToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTxtLeftMargin = new System.Windows.Forms.ToolStripTextBox();
            this.ightToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripTxtRight = new System.Windows.Forms.ToolStripTextBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.printPreviewDialog1 = new System.Windows.Forms.PrintPreviewDialog();
            this.printDocument1 = new System.Drawing.Printing.PrintDocument();
            this.printDialog1 = new System.Windows.Forms.PrintDialog();
            this.fontDialog1 = new System.Windows.Forms.FontDialog();
            this.tabControl1.SuspendLayout();
            this.tabCalculate.SuspendLayout();
            this.tabFormulas.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabCalculate);
            this.tabControl1.Controls.Add(this.tabFormulas);
            this.tabControl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 16F);
            this.tabControl1.Location = new System.Drawing.Point(13, 59);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(788, 480);
            this.tabControl1.TabIndex = 0;
            // 
            // tabCalculate
            // 
            this.tabCalculate.BackgroundImage = global::Fin_Calculator.Properties.Resources.money;
            this.tabCalculate.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.tabCalculate.Controls.Add(this.btnCalculate);
            this.tabCalculate.Controls.Add(this.lblOutput);
            this.tabCalculate.Controls.Add(this.txtN);
            this.tabCalculate.Controls.Add(this.label4);
            this.tabCalculate.Controls.Add(this.txtR);
            this.tabCalculate.Controls.Add(this.label3);
            this.tabCalculate.Controls.Add(this.txtT);
            this.tabCalculate.Controls.Add(this.label2);
            this.tabCalculate.Controls.Add(this.txtP);
            this.tabCalculate.Controls.Add(this.label1);
            this.tabCalculate.Location = new System.Drawing.Point(4, 34);
            this.tabCalculate.Name = "tabCalculate";
            this.tabCalculate.Padding = new System.Windows.Forms.Padding(3);
            this.tabCalculate.Size = new System.Drawing.Size(780, 442);
            this.tabCalculate.TabIndex = 0;
            this.tabCalculate.Text = "Calculate";
            this.tabCalculate.UseVisualStyleBackColor = true;
            // 
            // btnCalculate
            // 
            this.btnCalculate.Location = new System.Drawing.Point(253, 90);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(142, 33);
            this.btnCalculate.TabIndex = 9;
            this.btnCalculate.Text = "Calculate";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.btnCalculate.Click += new System.EventHandler(this.btnCalculate_Click);
            // 
            // lblOutput
            // 
            this.lblOutput.AutoSize = true;
            this.lblOutput.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.lblOutput.Location = new System.Drawing.Point(254, 136);
            this.lblOutput.Name = "lblOutput";
            this.lblOutput.Size = new System.Drawing.Size(0, 26);
            this.lblOutput.TabIndex = 8;
            // 
            // txtN
            // 
            this.txtN.Location = new System.Drawing.Point(61, 187);
            this.txtN.Name = "txtN";
            this.txtN.Size = new System.Drawing.Size(131, 32);
            this.txtN.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(22, 193);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(34, 26);
            this.label4.TabIndex = 6;
            this.label4.Text = "N:";
            // 
            // txtR
            // 
            this.txtR.Location = new System.Drawing.Point(61, 136);
            this.txtR.Name = "txtR";
            this.txtR.Size = new System.Drawing.Size(131, 32);
            this.txtR.TabIndex = 5;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(22, 142);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(34, 26);
            this.label3.TabIndex = 4;
            this.label3.Text = "R:";
            // 
            // txtT
            // 
            this.txtT.Location = new System.Drawing.Point(61, 88);
            this.txtT.Name = "txtT";
            this.txtT.Size = new System.Drawing.Size(131, 32);
            this.txtT.TabIndex = 3;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(22, 94);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(30, 26);
            this.label2.TabIndex = 2;
            this.label2.Text = "T:";
            // 
            // txtP
            // 
            this.txtP.Location = new System.Drawing.Point(61, 44);
            this.txtP.Name = "txtP";
            this.txtP.Size = new System.Drawing.Size(131, 32);
            this.txtP.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 50);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(33, 26);
            this.label1.TabIndex = 0;
            this.label1.Text = "P:";
            // 
            // tabFormulas
            // 
            this.tabFormulas.BackgroundImage = global::Fin_Calculator.Properties.Resources.money;
            this.tabFormulas.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.tabFormulas.Controls.Add(this.pictureBox1);
            this.tabFormulas.Location = new System.Drawing.Point(4, 34);
            this.tabFormulas.Name = "tabFormulas";
            this.tabFormulas.Padding = new System.Windows.Forms.Padding(3);
            this.tabFormulas.Size = new System.Drawing.Size(780, 442);
            this.tabFormulas.TabIndex = 1;
            this.tabFormulas.Text = "Formulas";
            this.tabFormulas.UseVisualStyleBackColor = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Fin_Calculator.Properties.Resources.Formulas;
            this.pictureBox1.Location = new System.Drawing.Point(15, 41);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(405, 322);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.optionsToolStripMenuItem1});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(813, 38);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // optionsToolStripMenuItem1
            // 
            this.optionsToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem1,
            this.printToolStripMenuItem1,
            this.fontToolStripMenuItem1,
            this.fontColorToolStripMenuItem1,
            this.marginsToolStripMenuItem1});
            this.optionsToolStripMenuItem1.Font = new System.Drawing.Font("Segoe UI", 16F);
            this.optionsToolStripMenuItem1.Name = "optionsToolStripMenuItem1";
            this.optionsToolStripMenuItem1.Size = new System.Drawing.Size(101, 34);
            this.optionsToolStripMenuItem1.Text = "Options";
            // 
            // printPreviewToolStripMenuItem1
            // 
            this.printPreviewToolStripMenuItem1.Name = "printPreviewToolStripMenuItem1";
            this.printPreviewToolStripMenuItem1.Size = new System.Drawing.Size(212, 34);
            this.printPreviewToolStripMenuItem1.Text = "Print Preview";
            this.printPreviewToolStripMenuItem1.Click += new System.EventHandler(this.printPreviewToolStripMenuItem1_Click);
            // 
            // printToolStripMenuItem1
            // 
            this.printToolStripMenuItem1.Name = "printToolStripMenuItem1";
            this.printToolStripMenuItem1.Size = new System.Drawing.Size(212, 34);
            this.printToolStripMenuItem1.Text = "Print";
            this.printToolStripMenuItem1.Click += new System.EventHandler(this.printToolStripMenuItem1_Click);
            // 
            // fontToolStripMenuItem1
            // 
            this.fontToolStripMenuItem1.Name = "fontToolStripMenuItem1";
            this.fontToolStripMenuItem1.Size = new System.Drawing.Size(212, 34);
            this.fontToolStripMenuItem1.Text = "Font";
            this.fontToolStripMenuItem1.Click += new System.EventHandler(this.fontToolStripMenuItem1_Click);
            // 
            // fontColorToolStripMenuItem1
            // 
            this.fontColorToolStripMenuItem1.Name = "fontColorToolStripMenuItem1";
            this.fontColorToolStripMenuItem1.Size = new System.Drawing.Size(212, 34);
            this.fontColorToolStripMenuItem1.Text = "Font Color";
            this.fontColorToolStripMenuItem1.Click += new System.EventHandler(this.fontColorToolStripMenuItem1_Click);
            // 
            // marginsToolStripMenuItem1
            // 
            this.marginsToolStripMenuItem1.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.leftToolStripMenuItem1,
            this.txtLeftMargin,
            this.upperToolStripMenuItem,
            this.txtUpperMargin});
            this.marginsToolStripMenuItem1.Name = "marginsToolStripMenuItem1";
            this.marginsToolStripMenuItem1.Size = new System.Drawing.Size(212, 34);
            this.marginsToolStripMenuItem1.Text = "Margins";
            // 
            // leftToolStripMenuItem1
            // 
            this.leftToolStripMenuItem1.Name = "leftToolStripMenuItem1";
            this.leftToolStripMenuItem1.Size = new System.Drawing.Size(180, 34);
            this.leftToolStripMenuItem1.Text = "Left:";
            // 
            // txtLeftMargin
            // 
            this.txtLeftMargin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtLeftMargin.Name = "txtLeftMargin";
            this.txtLeftMargin.Size = new System.Drawing.Size(100, 23);
            // 
            // upperToolStripMenuItem
            // 
            this.upperToolStripMenuItem.Name = "upperToolStripMenuItem";
            this.upperToolStripMenuItem.Size = new System.Drawing.Size(180, 34);
            this.upperToolStripMenuItem.Text = "Upper:";
            // 
            // txtUpperMargin
            // 
            this.txtUpperMargin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtUpperMargin.Name = "txtUpperMargin";
            this.txtUpperMargin.Size = new System.Drawing.Size(100, 23);
            // 
            // optionsToolStripMenuItem
            // 
            this.optionsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.printPreviewToolStripMenuItem,
            this.printToolStripMenuItem,
            this.fontToolStripMenuItem,
            this.fontColorToolStripMenuItem,
            this.marginsToolStripMenuItem});
            this.optionsToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 16F);
            this.optionsToolStripMenuItem.Name = "optionsToolStripMenuItem";
            this.optionsToolStripMenuItem.Size = new System.Drawing.Size(101, 34);
            this.optionsToolStripMenuItem.Text = "Options";
            // 
            // printPreviewToolStripMenuItem
            // 
            this.printPreviewToolStripMenuItem.Name = "printPreviewToolStripMenuItem";
            this.printPreviewToolStripMenuItem.Size = new System.Drawing.Size(212, 34);
            this.printPreviewToolStripMenuItem.Text = "Print Preview";
            // 
            // printToolStripMenuItem
            // 
            this.printToolStripMenuItem.Name = "printToolStripMenuItem";
            this.printToolStripMenuItem.Size = new System.Drawing.Size(212, 34);
            this.printToolStripMenuItem.Text = "Print";
            // 
            // fontToolStripMenuItem
            // 
            this.fontToolStripMenuItem.Name = "fontToolStripMenuItem";
            this.fontToolStripMenuItem.Size = new System.Drawing.Size(212, 34);
            this.fontToolStripMenuItem.Text = "Font";
            // 
            // fontColorToolStripMenuItem
            // 
            this.fontColorToolStripMenuItem.Name = "fontColorToolStripMenuItem";
            this.fontColorToolStripMenuItem.Size = new System.Drawing.Size(212, 34);
            this.fontColorToolStripMenuItem.Text = "Font Color";
            // 
            // marginsToolStripMenuItem
            // 
            this.marginsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.leftToolStripMenuItem,
            this.toolStripTxtLeftMargin,
            this.ightToolStripMenuItem,
            this.toolStripTxtRight});
            this.marginsToolStripMenuItem.Name = "marginsToolStripMenuItem";
            this.marginsToolStripMenuItem.Size = new System.Drawing.Size(212, 34);
            this.marginsToolStripMenuItem.Text = "Margins";
            // 
            // leftToolStripMenuItem
            // 
            this.leftToolStripMenuItem.Name = "leftToolStripMenuItem";
            this.leftToolStripMenuItem.Size = new System.Drawing.Size(160, 34);
            this.leftToolStripMenuItem.Text = "Left:";
            // 
            // toolStripTxtLeftMargin
            // 
            this.toolStripTxtLeftMargin.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTxtLeftMargin.Name = "toolStripTxtLeftMargin";
            this.toolStripTxtLeftMargin.Size = new System.Drawing.Size(100, 23);
            // 
            // ightToolStripMenuItem
            // 
            this.ightToolStripMenuItem.Name = "ightToolStripMenuItem";
            this.ightToolStripMenuItem.Size = new System.Drawing.Size(160, 34);
            this.ightToolStripMenuItem.Text = "Right:";
            // 
            // toolStripTxtRight
            // 
            this.toolStripTxtRight.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.toolStripTxtRight.Name = "toolStripTxtRight";
            this.toolStripTxtRight.Size = new System.Drawing.Size(100, 23);
            // 
            // printPreviewDialog1
            // 
            this.printPreviewDialog1.AutoScrollMargin = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.AutoScrollMinSize = new System.Drawing.Size(0, 0);
            this.printPreviewDialog1.ClientSize = new System.Drawing.Size(400, 300);
            this.printPreviewDialog1.Enabled = true;
            this.printPreviewDialog1.Icon = ((System.Drawing.Icon)(resources.GetObject("printPreviewDialog1.Icon")));
            this.printPreviewDialog1.Name = "printPreviewDialog1";
            this.printPreviewDialog1.Visible = false;
            // 
            // printDocument1
            // 
            this.printDocument1.PrintPage += new System.Drawing.Printing.PrintPageEventHandler(this.printDocument1_PrintPage);
            // 
            // printDialog1
            // 
            this.printDialog1.Document = this.printDocument1;
            this.printDialog1.UseEXDialog = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(813, 551);
            this.Controls.Add(this.tabControl1);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "Form1";
            this.Text = "Form1";
            this.tabControl1.ResumeLayout(false);
            this.tabCalculate.ResumeLayout(false);
            this.tabCalculate.PerformLayout();
            this.tabFormulas.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabCalculate;
        private System.Windows.Forms.TabPage tabFormulas;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.PrintPreviewDialog printPreviewDialog1;
        private System.Drawing.Printing.PrintDocument printDocument1;
        private System.Windows.Forms.PrintDialog printDialog1;
        private System.Windows.Forms.FontDialog fontDialog1;
        private System.Windows.Forms.Button btnCalculate;
        private System.Windows.Forms.Label lblOutput;
        private System.Windows.Forms.TextBox txtN;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtR;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtT;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtP;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fontColorToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem marginsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem leftToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox toolStripTxtLeftMargin;
        private System.Windows.Forms.ToolStripMenuItem ightToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox toolStripTxtRight;
        private System.Windows.Forms.ToolStripMenuItem optionsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem printToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fontToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem fontColorToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem marginsToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem leftToolStripMenuItem1;
        private System.Windows.Forms.ToolStripTextBox txtLeftMargin;
        private System.Windows.Forms.ToolStripMenuItem upperToolStripMenuItem;
        private System.Windows.Forms.ToolStripTextBox txtUpperMargin;
        private System.Windows.Forms.ToolStripMenuItem printPreviewToolStripMenuItem1;
    }
}

